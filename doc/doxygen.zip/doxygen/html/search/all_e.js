var searchData=
[
  ['tetriswidget_29',['TetrisWidget',['../class_tetris_widget.html',1,'TetrisWidget'],['../class_tetris_widget.html#af8920e594d0282be169b9eb14088134d',1,'TetrisWidget::TetrisWidget()']]]
];
