var searchData=
[
  ['paintevent_21',['paintEvent',['../class_next_piece.html#a54e535ce4f5b4b1cd2b96213db18322f',1,'NextPiece::paintEvent()'],['../class_tetris_widget.html#af748d7470db0b3445ee82da6ee3e6d5e',1,'TetrisWidget::paintEvent()']]]
];
