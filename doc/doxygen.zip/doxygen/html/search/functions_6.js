var searchData=
[
  ['keypressevent_43',['keyPressEvent',['../class_tetris_widget.html#a2adb5bbcf8daedbaa3d1d488e6e0a8f8',1,'TetrisWidget']]]
];
