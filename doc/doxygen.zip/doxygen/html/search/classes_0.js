var searchData=
[
  ['border_30',['Border',['../struct_border.html',1,'']]]
];
