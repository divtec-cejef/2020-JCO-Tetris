var searchData=
[
  ['getborder_39',['getBorder',['../class_tetris_widget.html#a5bbbfd209332047c2f426ebc4362ddd0',1,'TetrisWidget']]]
];
