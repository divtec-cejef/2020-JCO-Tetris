var searchData=
[
  ['tetriswidget_33',['TetrisWidget',['../class_tetris_widget.html',1,'']]]
];
