var searchData=
[
  ['on_5fbt_5fstart_5fclicked_45',['on_BT_Start_clicked',['../class_main_frm.html#a02966d3e8d47ff40a5ea7f81bd337b79',1,'MainFrm']]],
  ['onendofgame_46',['onEndOfGame',['../class_main_frm.html#a0244ca29baa4b7061d53cb00857e5ae0',1,'MainFrm']]],
  ['onfourrowdeleted_47',['onFourRowDeleted',['../class_main_frm.html#a588e4d4c923f022c2c9363bae2b1d592',1,'MainFrm']]],
  ['ononerowdeleted_48',['onOneRowDeleted',['../class_main_frm.html#a1b020a37457da4d290660060d7c3619a',1,'MainFrm']]],
  ['onrowdeleted_49',['onRowDeleted',['../class_main_frm.html#aac2ae70b888bb4d3c12d9707891d5e21',1,'MainFrm']]],
  ['onthreerowdeleted_50',['onThreeRowDeleted',['../class_main_frm.html#af13159684c8e64279e4c17b8cf1312db',1,'MainFrm']]],
  ['ontworowdeleted_51',['onTwoRowDeleted',['../class_main_frm.html#ae4c81c1a7228c249dad519df546a7aca',1,'MainFrm']]]
];
