var searchData=
[
  ['changetable_36',['changeTable',['../class_tetris_widget.html#adec409be01c51e2b89aeea2560bcbf22',1,'TetrisWidget']]],
  ['clearrow_37',['clearRow',['../class_tetris_widget.html#a251c24b2224003be2a54157b00bd0e05',1,'TetrisWidget']]]
];
