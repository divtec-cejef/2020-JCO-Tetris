var searchData=
[
  ['leftpiece_11',['leftPiece',['../class_tetris_widget.html#a994a7635a27fd7bf2e81f4a7783c38ca',1,'TetrisWidget']]]
];
