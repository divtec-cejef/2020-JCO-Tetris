var searchData=
[
  ['addpiece_0',['addPiece',['../class_tetris_widget.html#a32e784d74265799d801b1eaae6c0862b',1,'TetrisWidget']]]
];
