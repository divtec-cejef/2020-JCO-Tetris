var searchData=
[
  ['blockrotate_1',['blockRotate',['../class_tetris_widget.html#a864c31aaeaefa24289c8fb36efaaec56',1,'TetrisWidget']]],
  ['border_2',['Border',['../struct_border.html',1,'']]]
];
