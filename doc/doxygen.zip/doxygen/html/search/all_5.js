var searchData=
[
  ['initstyle_7',['initStyle',['../class_main_frm.html#a060abade3d63cd6db256f56e7aeb9028',1,'MainFrm']]],
  ['inittimer_8',['initTimer',['../class_tetris_widget.html#a7bb0a7c10785e428980e9da5894b71fb',1,'TetrisWidget']]],
  ['isgameover_9',['isGameOver',['../class_tetris_widget.html#ad9138320d4d74c0325446f6b95d4a11d',1,'TetrisWidget']]]
];
