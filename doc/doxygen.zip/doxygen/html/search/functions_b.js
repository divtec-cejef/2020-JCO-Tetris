var searchData=
[
  ['settimer_55',['setTimer',['../class_tetris_widget.html#aa296eca46ef231e19f0ba18ff0216057',1,'TetrisWidget']]],
  ['startmusic_56',['startMusic',['../class_tetris_widget.html#a86c2daa74715f1c126dd9167cc024945',1,'TetrisWidget']]],
  ['starttimer_57',['startTimer',['../class_tetris_widget.html#a0edccb43f53e201634bc472072ced58e',1,'TetrisWidget']]],
  ['stopmusic_58',['stopMusic',['../class_tetris_widget.html#a55c9efcda6380fb05a04d04359499c31',1,'TetrisWidget']]],
  ['stoptimer_59',['stopTimer',['../class_tetris_widget.html#a378ec9dfee991ed9bfca291c7c29e87d',1,'TetrisWidget']]]
];
