var searchData=
[
  ['resetgame_22',['resetGame',['../class_tetris_widget.html#ac83ce71436c1a9706282c9b24eaf3a16',1,'TetrisWidget']]],
  ['rightpiece_23',['rightPiece',['../class_tetris_widget.html#af799816e485b52d93f85700763f35a7c',1,'TetrisWidget']]]
];
