var searchData=
[
  ['downpiece_38',['downPiece',['../class_tetris_widget.html#ad93689fe712ffcf9d37704f6c72603d0',1,'TetrisWidget']]]
];
