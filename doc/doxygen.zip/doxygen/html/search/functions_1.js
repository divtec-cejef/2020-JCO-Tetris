var searchData=
[
  ['blockrotate_35',['blockRotate',['../class_tetris_widget.html#a864c31aaeaefa24289c8fb36efaaec56',1,'TetrisWidget']]]
];
