/****************************************************************************
** Meta object code from reading C++ file 'tetriswidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../../git/2020-JCO-Tetris/src/tetriswidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tetriswidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TetrisWidget_t {
    QByteArrayData data[9];
    char stringdata0[104];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TetrisWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TetrisWidget_t qt_meta_stringdata_TetrisWidget = {
    {
QT_MOC_LITERAL(0, 0, 12), // "TetrisWidget"
QT_MOC_LITERAL(1, 13, 9), // "endOfGame"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 10), // "rowDeleted"
QT_MOC_LITERAL(4, 35, 13), // "oneRowDeleted"
QT_MOC_LITERAL(5, 49, 13), // "twoRowDeleted"
QT_MOC_LITERAL(6, 63, 15), // "threeRowDeleted"
QT_MOC_LITERAL(7, 79, 14), // "fourRowDeleted"
QT_MOC_LITERAL(8, 94, 9) // "initTimer"

    },
    "TetrisWidget\0endOfGame\0\0rowDeleted\0"
    "oneRowDeleted\0twoRowDeleted\0threeRowDeleted\0"
    "fourRowDeleted\0initTimer"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TetrisWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x06 /* Public */,
       3,    0,   50,    2, 0x06 /* Public */,
       4,    0,   51,    2, 0x06 /* Public */,
       5,    0,   52,    2, 0x06 /* Public */,
       6,    0,   53,    2, 0x06 /* Public */,
       7,    0,   54,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,   55,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void TetrisWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TetrisWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->endOfGame(); break;
        case 1: _t->rowDeleted(); break;
        case 2: _t->oneRowDeleted(); break;
        case 3: _t->twoRowDeleted(); break;
        case 4: _t->threeRowDeleted(); break;
        case 5: _t->fourRowDeleted(); break;
        case 6: _t->initTimer(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TetrisWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TetrisWidget::endOfGame)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TetrisWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TetrisWidget::rowDeleted)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TetrisWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TetrisWidget::oneRowDeleted)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (TetrisWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TetrisWidget::twoRowDeleted)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (TetrisWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TetrisWidget::threeRowDeleted)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (TetrisWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TetrisWidget::fourRowDeleted)) {
                *result = 5;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject TetrisWidget::staticMetaObject = { {
    &QFrame::staticMetaObject,
    qt_meta_stringdata_TetrisWidget.data,
    qt_meta_data_TetrisWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TetrisWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TetrisWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TetrisWidget.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int TetrisWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void TetrisWidget::endOfGame()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void TetrisWidget::rowDeleted()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void TetrisWidget::oneRowDeleted()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void TetrisWidget::twoRowDeleted()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void TetrisWidget::threeRowDeleted()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void TetrisWidget::fourRowDeleted()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
